import React from 'react';
import './App.css';

function App() {
  return (
    <div className="container mt-5">
      <h1 className="mb-4">Botão e card com react e bootstrap</h1>

      {/* Botão */}
      <button className="btn btn-primary mb-4">Botão</button>

      {/* Card */}
      <div className="card" style={{ width: '18rem' }}>
        <img 
          src="https://blog.polipet.com.br/wp-content/uploads/2024/01/pato.jpeg" 
          className="card-img-top" 
          alt="Pato fofo" 
        />
        <div className="card-body">
          <h5 className="card-title">Piriripororo</h5>
          <p className="card-text">
            Cardzinho muito top.
          </p>
          <a href="#" className="btn btn-secondary">Botão</a>
        </div>
      </div>
    </div>
  );
}

export default App;
